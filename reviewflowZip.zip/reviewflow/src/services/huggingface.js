const axios = require("axios");
const Sentiment = require("sentiment");
const logger = require("./logger");
const { canUseAI, recordUse } = require("./aiBudget");
const { SENTIMENTS, SENTIMENT_CACHE_TTL_MS } = require("../config/constants");

const cache = new Map();
const localAnalyzer = new Sentiment();

async function callGroq(prompt) {
  const { data } = await axios.post(
    "https://api.groq.com/openai/v1/chat/completions",
    {
      model: "llama-3.3-70b-versatile",
      messages: [{ role: "user", content: prompt }],
    },
    { headers: { Authorization: `Bearer ${process.env.GROQ_API_KEY}` }, timeout: 10000 }
  );
  return (data.choices?.[0]?.message?.content || "").trim();
}

// Used when the daily budget is exhausted or Groq itself fails — the
// local library from earlier, so quality degrades gracefully instead of
// the whole feature going dark.
function localSentimentFallback(message) {
  const result = localAnalyzer.analyze(message || "");
  const sentiment = result.score > 0 ? SENTIMENTS.HAPPY : result.score < 0 ? SENTIMENTS.SAD : SENTIMENTS.NEUTRAL;
  return { sentiment, confidence: 0.5, intent: "local_fallback_budget_or_error" };
}

async function analyzeSentiment(message) {
  const cacheKey = `sentiment:${message}`;
  const cached = cache.get(cacheKey);
  if (cached && cached.expiresAt > Date.now()) return cached.result;

  if (!process.env.GROQ_API_KEY || !canUseAI()) {
    return localSentimentFallback(message);
  }

  try {
    const text = await callGroq(
      `Classify sentiment (English/Hindi/Hinglish) as exactly one word: happy, neutral, or sad. Message: "${message}". Reply with only the word.`
    );
    recordUse();
    const lower = text.toLowerCase();
    const sentiment = lower.includes("happy") ? SENTIMENTS.HAPPY : lower.includes("sad") ? SENTIMENTS.SAD : SENTIMENTS.NEUTRAL;
    const result = { sentiment, confidence: 0.8, intent: "groq" };
    cache.set(cacheKey, { result, expiresAt: Date.now() + SENTIMENT_CACHE_TTL_MS });
    return result;
  } catch (err) {
    logger.error("Groq sentiment failed, using local fallback:", err.message);
    return localSentimentFallback(message);
  }
}

async function craftReply(message, sentiment, item) {
  if (!process.env.GROQ_API_KEY || !canUseAI()) return null;
  const tone = sentiment === SENTIMENTS.SAD ? "empathetic, apologetic" : "warm, appreciative";
  const itemContext = item ? ` They came in for: ${item}.` : "";
  const prompt = `You are a friendly WhatsApp assistant for "Sharma Cafe Pune".${itemContext} A customer just said: "${message}". ` +
    `Write ONE short reply (under 25 words, ${tone} tone, Hindi/English mix is fine) acknowledging what they said. ` +
    `No discounts, no ratings, no requests — just a natural acknowledgment. Reply with only the message text.`;
  try {
    const reply = await callGroq(prompt);
    recordUse();
    return reply;
  } catch (err) {
    logger.error("Groq reply generation failed:", err.message);
    return null;
  }
}

module.exports = { analyzeSentiment, craftReply };