const express = require("express");
const router = express.Router();
const storage = require("../services/storage");
const { DEMO_BUSINESS } = require("../config/constants");

// GET /r/:id — customer taps this instead of the raw Google link.
router.get("/:id", (req, res) => {
  storage.markClicked(req.params.id);
  res.redirect(DEMO_BUSINESS.googleReviewUrl);
});

module.exports = router;