const express = require("express");
const router = express.Router();
const twilioService = require("../services/twilio");
const { classifyMessage } = require("../services/sentiment");
const storage = require("../services/storage");
const logger = require("../services/logger");
const templates = require("../utils/hinglishTemplates");
const { STATES, SENTIMENTS, STATE_TTL_MS, DEMO_BUSINESS } = require("../config/constants");

// In-memory conversation state: Map<phone, { state, sentiment, expiresAt, customerName }>
const conversations = new Map();

function getConversation(phone) { return getState(phone); }
function seedConversation(phone, data) { setState(phone, data); }

function getState(phone) {
  const entry = conversations.get(phone);
  if (!entry) return null;
  if (entry.expiresAt < Date.now()) {
    conversations.delete(phone);
    return null;
  }
  return entry;
}

function setState(phone, patch) {
  const existing = conversations.get(phone) || {};
  conversations.set(phone, { ...existing, ...patch, expiresAt: Date.now() + STATE_TTL_MS });
}

// POST /webhook/whatsapp — Twilio calls this on every inbound message.
router.post("/whatsapp", async (req, res, next) => {
  try {
    if (!twilioService.validateSignature(req)) {
      return res.status(403).json({ error: "Invalid Twilio signature" });
    }

    const from = req.body.From || "unknown";
    const body = (req.body.Body || "").trim();
    let convo = getState(from) || { state: STATES.INIT, customerName: "Customer" };

    let replyText;

    if (convo.state === STATES.INIT || convo.state === STATES.AWAITING_RATING) {
      // Classify whatever came in as the rating response.
      const { sentiment } = await classifyMessage(body);
      setState(from, { state: sentiment === SENTIMENTS.SAD ? STATES.AWAITING_FEEDBACK : STATES.AWAITING_REVIEW, sentiment });

      if (sentiment === SENTIMENTS.SAD) {
        const reply = await craftReply(body, sentiment, convo.item);
        replyText = `${reply || templates.sadReply()}\n${DEMO_BUSINESS.feedbackFormUrl}`;
        await twilioService.sendWhatsApp(DEMO_BUSINESS.managerWhatsapp, `⚠️ Unhappy customer alert: ${from} rated their visit poorly.`);
        storage.appendRecord({ phone: from, customerName: convo.customerName, sentiment, state: STATES.AWAITING_FEEDBACK, triggerSource: "webhook" });
      } else {
        const record = storage.appendRecord({ phone: from, customerName: convo.customerName, sentiment, state: STATES.AWAITING_REVIEW, triggerSource: "webhook" });
        const trackingLink = `${process.env.BASE_URL}/r/${record.id}`;
        const reply = await craftReply(body, sentiment, convo.item);
        replyText = `${reply || templates.happyReply()}\n${trackingLink}`;
      }

      storage.appendRecord({
        phone: from,
        customerName: convo.customerName,
        sentiment,
        state: getState(from).state,
        triggerSource: "webhook",
      });
    } else if (convo.state === STATES.AWAITING_REVIEW) {
      setState(from, { state: STATES.COMPLETED });
      replyText = templates.reviewConfirmation();
      storage.appendRecord({ phone: from, customerName: convo.customerName, sentiment: SENTIMENTS.HAPPY, state: STATES.COMPLETED, reviewText: body, triggerSource: "webhook" });
    } else if (convo.state === STATES.AWAITING_FEEDBACK) {
      setState(from, { state: STATES.COMPLETED });
      replyText = templates.feedbackFollowup();
      storage.appendRecord({ phone: from, customerName: convo.customerName, sentiment: SENTIMENTS.SAD, state: STATES.COMPLETED, feedbackText: body, triggerSource: "webhook" });
    } else {
      replyText = "Thanks again! 🙏";
    }

    await twilioService.sendWhatsApp(from, replyText);
    res.status(200).send("<Response></Response>"); // TwiML no-op ack
  } catch (err) {
    next(err);
  }
});

module.exports = router;
module.exports.getConversation = getConversation;
module.exports.seedConversation = seedConversation;