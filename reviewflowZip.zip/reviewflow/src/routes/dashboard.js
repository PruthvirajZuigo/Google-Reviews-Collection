const express = require("express");
const router = express.Router();
const storage = require("../services/storage");
const { SENTIMENTS } = require("../config/constants");

router.get("/data", (req, res) => {
  const records = storage.readAll();
  const happy = records.filter((r) => r.sentiment === "happy").length;
  const neutral = records.filter((r) => r.sentiment === "neutral").length;
  const sad = records.filter((r) => r.sentiment === "sad").length;

  const withStage = records.map((r) => {
    let stage;
    if (r.state === "AWAITING_RATING" || !r.sentiment) stage = r.triggerSource === "followup_reminder" ? "1. Reminder sent" : "1. Waiting for reply";
    else if (r.sentiment === "sad") stage = r.feedbackText ? "3. Feedback shared" : "3. Awaiting feedback";
    else stage = "2. Sent to Google";
    return { ...r, stage };
  });

  res.json({ totalMessages: records.length, happy, neutral, sad, recent: withStage.slice(-20).reverse() });
});

module.exports = router;