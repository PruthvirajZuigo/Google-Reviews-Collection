const { DEMO_BUSINESS } = require("../config/constants");

function pick(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

const WELCOME = [
  (name, item) => `Hi! Thank you for visiting ${name}${item ? ` for ${item}` : ""} 😊 Aapka experience kaisa raha?`,
  (name, item) => `Namaste! ${item ? `Hope you enjoyed your ${item} at ` : "Payment received for "}${name} ✅ Kaisa laga?`,
  (name, item) => `Thanks for choosing ${name}${item ? ` — how was the ${item}?` : "!"} 😊`,
  (name, item) => `Hey! ${item ? `Your ${item} at ` : ""}${name} kaisa raha? Ek emoji bhej dijiye 🙂`,
  (name, item) => `Shukriya ${name} choose karne ke liye${item ? ` (${item})` : ""}! Rating dena chahenge? 😄😐😞`,
];

const FOLLOWUP_REMINDER = [
  (name) => `Hey! Just checking in — how was your visit to ${name}? Would love to know 😊`,
  (name) => `Hi again! No pressure, just curious how things went at ${name}?`,
  (name) => `Quick nudge — kaisa raha aapka experience ${name} mein? 🙂`,
  (name) => `Hope you're doing well! Missed hearing back about your visit to ${name}.`,
  (name) => `Just following up — would love your quick thoughts on ${name} 😊`,
];

const HAPPY_REPLY = [
  () => "Sunke bahut khushi hui! 🎉 Would you mind sharing this on Google?",
  () => "That's wonderful! Ek chhota sa Google review help karega bahut sare logo ko 🙏",
  () => "Yay! Glad you enjoyed it 😄 Google par 2 lines likh denge?",
  () => "Great to hear! Aapka feedback Google par share kar sakte hain?",
  () => "Awesome! 🌟 Mind dropping a quick review on Google for us?",
];

const SAD_REPLY = [
  () => "Sorry to hear that 😔 Please tell us what went wrong so we can fix it.",
  () => "Maaf kijiye, aapka experience achha nahi raha. Please share details, hum improve karenge.",
  () => "That's not the experience we want for you. Please fill this quick form so our manager can help.",
  () => "Sorry! Aapki baat manager tak pahunchayenge turant. Please share more here:",
  () => "We're sorry 🙏 Please let us know the issue below so we can make it right.",
];

const REVIEW_CONFIRMATION = [
  () => "Thank you so much for the review! 🙏 Really appreciate it.",
  () => "Shukriya! Aapka review humare liye bahut matter karta hai 🌟",
  () => "Got it — thanks a ton! See you again soon 😊",
  () => "Review mil gaya, dhanyawaad! Aapka din shubh ho 🙏",
  () => "Thanks for taking the time! We appreciate you 🎉",
];

const FEEDBACK_FOLLOWUP = [
  () => "Thanks for letting us know. Our manager will reach out shortly.",
  () => "Noted — hum jald hi contact karenge is issue ke liye.",
  () => "Appreciate your patience 🙏 Manager ko turant inform kar diya hai.",
  () => "Thank you for the honest feedback, we're on it.",
  () => "Got your message — hum isse seriously le rahe hain, thank you.",
];

module.exports = {
  welcomeMessage: (name, item) => pick(WELCOME)(name, item),
  happyReply: () => pick(HAPPY_REPLY)(),
  sadReply: () => pick(SAD_REPLY)(),
  reviewConfirmation: () => pick(REVIEW_CONFIRMATION)(),
  feedbackFollowup: () => pick(FEEDBACK_FOLLOWUP)(),
  followupReminder: (name) => pick(FOLLOWUP_REMINDER)(name),
};